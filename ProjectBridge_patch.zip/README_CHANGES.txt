Kiwi Studios 2 — shader library and Natural Materials

IMPLEMENTED LOCALLY
All source changes are already present in the authorized local working tree. Nothing was pushed to GitHub. ProjectBridge_patch.zip is the required portable delivery of those same changes, with exact original bytes for safe conflict checks and three-way merging.

FEATURES
- Existing shader documentation extended with searchable Samples and Templates, type/category filters, favorites, recents, complete source, contextual Apply, copy/open/save actions and actual lazy cached rendered previews. Large previews support animation, uniforms, geometry, orbit and zoom.
- 142 distinct complete samples and 20 separate complete templates covering 2D, animation, 3D surfaces/deformation, sky, fog, particles and special effects.
- Shared deterministic procedural engine: 143 presets across Metal, Wood, Fabric, Stone, Ground, Organic, Weathering, Illustration, Geometry and Noise. Existing material IDs and legacy recipe compatibility retained.
- Structural algorithms: directional grain/rings/knots; brushed scratches, corrosion and hammer dents; interlaced weave, curl and knit; mineral particles/veins/pores/cracks/masonry; dunes/grains/rounded stones/clumps/blades; halftone/hatching/stippling/ink and generic noise families.
- Brush and Bucket Color/Material modes, independent remembered tool settings, stable texture coordinates, meaningful controls, structural emboss, shared nonmodal browser and actual canvas feedback.
- Unified color/material brush presets with automatic mode switching, filtering, creation, save-as, rename, duplicate, reorder, favorites and persistence.
- Live Material Templates with stable ownership, masks/mapping, ordered raster/live content, immediate linked updates, undo/redo, native saving/reopening, independent delete and selective bake. Integrated stamp/scatter coordinates remain editable.
- Natural Material registered through the existing actor object/reference catalog, accepted by general 3D material slots, shared settings/presets, UV/triplanar procedural mapping, roughness/metallic and height-derived normal response. Existing Material/ShaderMaterial and specialized context restrictions preserved.

PERFORMANCE AND ARCHITECTURE
The same GLSL evaluator supplies 2D and 3D structure. Driver compilation specializes families and removes unused mixers. Shader/map/thumbnail caches are bounded; transparent coverage skips expensive evaluation. Shader previews use two reusable viewports instead of a running viewport per card. Live parameter edits reuse masks and textures. Unchanged image-layer render targets sleep; affected, clipped/grouped and animated dependencies invalidate appropriately. Stamp coordinate maps are optional, capped at 2048 pixels per dimension, and cropped to stroke bounds. Interactive source rendering follows zoom tiers and caps dimensions at 2048 pixels during gestures, then refines after 350ms idle. Native masks, one-pixel Bucket detection, saving, export and baking remain full resolution and were tested against native rendered references.

VISUAL VALIDATION
Actual GPU renders were inspected: every material-family sheet, the full material catalog, shader category sheets, live-template workflow, nonmodal material browser, shader browser, paired 2D/3D material surfaces and the native/interactive/refined preview comparison. Compiler success was supplemented by visual inspection. This found and corrected wood knot discontinuities, cramped dock controls, oversized/correlated particles and numerical noise-hash seams.

LIMITATIONS
- Particle process shaders preview/copy/open/save correctly, but existing actor definitions expose no process-material slot; direct Apply is disabled with an explanation.
- Godot fog rendering requires Forward+. Compatibility shows a clear unsupported-context explanation.
- Triplanar projection covers the primary procedural 3D material; imported images and advanced secondary mixtures use UV mapping.
- Hidden live templates must be shown before baking.
- Full-resolution coverage masks consume memory; many alternating template/raster regions can grow document memory. Region topology changes rebuild the layer graph; parameter-only edits reuse it. Stamp coordinate-map resolution is capped, so extremely large stamps can have less mapping precision.
- Large-document performance depends on resolution, effect chains, material complexity and hardware; measured results below are workload-specific and do not guarantee 60 FPS for arbitrary projects.
- Executable export was not performed: this machine has no Godot 4.6.1 export templates. Source dependencies were made export-safe; image/native document export and reopen paths were exercised by tests.

VERIFICATION ENVIRONMENT
Godot 4.6.1 stable; NVIDIA RTX 3060 Laptop. Material catalog used actual OpenGL Compatibility rendering; shader catalog and integration tests used actual D3D12 Forward+. Headless checks were used only for data/parsing, never counted as rendered previews. GPU suites ran sequentially. Windows emitted a pre-existing root-certificate-store warning. Some older test harnesses emit shutdown resource warnings, also observed on the original baseline.

TESTS
Actor regression scripts: 64/64 passed; failed=[]; not_run=[].
Shader catalog: all 162 current-source hashes match actual passed render results; 80.12 seconds reported.
Material engine: 143 rendered presets/143 distinct pixel fingerprints, zero inactive exposed structural controls, deterministic settings/seed, seven representative exact periodic repeats, requested output maps, alpha/coverage, imported textures, mixing, spatial output and preset roundtrips passed. Five 256px maps took 87.81ms including render-frame waits; cached albedo took 0.17ms.
Editable-material brush CPU stress measurements: 64px 0.9ms, 256px 8.2ms, 1024px 124.2ms. Very large brushes remain CPU-expensive; adaptive rendering does not remove coverage-rasterization costs.
Tests exercise brush/bucket selection and opacity, Stroke Correct, presets, live recolor/scale independence, bake/delete/undo/save/reopen, mapping, layer groups/masks/clipping/transforms, scene material compatibility/undo, shader actions and compiler-error recovery. Stale baseline UI tests were updated to interact with the existing dimension chooser and locate previews by type instead of child index.
Two legacy Image test shutdown crashes were reproduced on the original baseline and diagnosed: fixture destruction occurred before asynchronous selection captures completed, and an unparented color-state control remained alive. Test-only cleanup now waits for rendered captures and frees the fixture-owned control. Both final Forward+ runs exit 0 with zero assertion failures and no resource leaks. Stroke-toolbar assertions were updated for the compact settings anchor and unchanged proportional wheel increments.
Disposable baseline replay: exact before/after hashes and original-byte bases validated; fresh Godot import passed=True in 11.23s; 6/6 additional Forward+ integration scripts passed on that reconstructed source tree.

LIVE MATERIAL BENCHMARK (two layers, six regions, three templates, 24 edits)
[
  {
    "coverage_regions_checked": 6,
    "coverage_unchanged": true,
    "frames": 24,
    "gpu_timestamps_available": true,
    "layers": 2,
    "mean_rendered_frame_wall_ms": 2.26079166666667,
    "mean_sync_cpu_ms": 0.96375,
    "mean_viewport_gpu_ms": 1.09725001112868,
    "mean_viewport_render_cpu_ms": 0.190166667996285,
    "median_rendered_frame_wall_ms": 2.197,
    "p95_rendered_frame_wall_ms": 2.633,
    "parameter_changed_rendered_pixels": true,
    "regions": 6,
    "renderer": "forward_plus",
    "size": "(1280, 720)",
    "templates": 3,
    "valid_rendered_output": true,
    "viewports_after": 11,
    "viewports_before": 11
  },
  {
    "coverage_regions_checked": 6,
    "coverage_unchanged": true,
    "frames": 24,
    "gpu_timestamps_available": true,
    "layers": 2,
    "mean_rendered_frame_wall_ms": 3.773875,
    "mean_sync_cpu_ms": 1.25008333333333,
    "mean_viewport_gpu_ms": 3.19804164829353,
    "mean_viewport_render_cpu_ms": 0.239125000817391,
    "median_rendered_frame_wall_ms": 3.801,
    "p95_rendered_frame_wall_ms": 3.936,
    "parameter_changed_rendered_pixels": true,
    "regions": 6,
    "renderer": "forward_plus",
    "size": "(2048, 2048)",
    "templates": 3,
    "valid_rendered_output": true,
    "viewports_after": 11,
    "viewports_before": 11
  },
  {
    "coverage_regions_checked": 6,
    "coverage_unchanged": true,
    "frames": 24,
    "gpu_timestamps_available": true,
    "layers": 2,
    "mean_rendered_frame_wall_ms": 144.849208333333,
    "mean_sync_cpu_ms": 1.544875,
    "mean_viewport_gpu_ms": 142.530375397454,
    "mean_viewport_render_cpu_ms": 0.248541667979831,
    "median_rendered_frame_wall_ms": 107.688,
    "p95_rendered_frame_wall_ms": 231.977,
    "parameter_changed_rendered_pixels": true,
    "regions": 6,
    "renderer": "forward_plus",
    "size": "(4096, 4096)",
    "templates": 3,
    "valid_rendered_output": true,
    "viewports_after": 11,
    "viewports_before": 11
  }
]

ADAPTIVE 4096px DOCUMENT BENCHMARK
[
  {
    "coverage_regions_checked": 6,
    "coverage_unchanged": true,
    "frames": 24,
    "gpu_timestamps_available": true,
    "layers": 2,
    "mean_rendered_frame_wall_ms": 2.8955,
    "mean_sync_cpu_ms": 1.14883333333333,
    "mean_viewport_gpu_ms": 2.51916666080554,
    "mean_viewport_render_cpu_ms": 0.253458335064352,
    "median_rendered_frame_wall_ms": 2.803,
    "p95_rendered_frame_wall_ms": 3.909,
    "parameter_changed_rendered_pixels": true,
    "preview_mode": "adaptive_interactive",
    "regions": 6,
    "render_scale": 0.5,
    "rendered_extent": "(2048, 2048)",
    "renderer": "forward_plus",
    "size": "(4096, 4096)",
    "templates": 3,
    "valid_rendered_output": true,
    "viewports_after": 11,
    "viewports_before": 11
  }
]

LATEST ACTOR TEST RESULTS
actor_keyframes_test: PASS, 6.75s, forward_plus
actor_picker_test: PASS, 15.235s, forward_plus
actor_smoke_test: PASS, 3.312s, forward_plus
actor_types_test: PASS, 9.047s, forward_plus
audio_sources_test: PASS, 7.313s, forward_plus
audio_test: PASS, 6.234s, forward_plus
brush_toolbar_layout_test: PASS, 5.656s, forward_plus
child_link_controls_test: PASS, 6.281s, forward_plus
image_adjustment_math_test: PASS, 5.359s, forward_plus
image_brush_types_test: PASS, 5.907s, forward_plus
image_material_painting_test: PASS, 8.547s, forward_plus
image_material_stamps_test: PASS, 6.234s, forward_plus
image_mirror_effect_test: PASS, 5.594s, forward_plus
image_open_dialog_test: PASS, 5.25s, forward_plus
image_repair_test: PASS, 6.609s, forward_plus
image_selection_fill_test: PASS, 6.594s, forward_plus
image_studio_test: PASS, 15.766s, forward_plus
image_texture_material_test: PASS, 17.797s, forward_plus
image_warp_test: PASS, 6.328s, forward_plus
keyframe_curves_components_test: PASS, 6.313s, forward_plus
keyframe_inline_test: PASS, 6.312s, forward_plus
keyframe_layout_test: PASS, 6.235s, forward_plus
live_material_cache_test: PASS, 5.047s, forward_plus
live_material_preview_test: PASS, 4.781s, forward_plus
live_material_templates_test: PASS, 4.532s, forward_plus
live_recording_placement_test: PASS, 6.312s, forward_plus
media_preview_recording_test: PASS, 6.485s, forward_plus
media_save_screen_test: PASS, 8.844s, forward_plus
natural_material_browser_test: PASS, 7.235s, forward_plus
natural_material_scene_render_test: PASS, 8.64s, forward_plus
natural_material_test: PASS, 11.61s, forward_plus
pixel_selection_integration_test: PASS, 8.406s, forward_plus
pixel_selection_worker_test: PASS, 6.562s, forward_plus
pixel_smart_selection_test: PASS, 4.438s, forward_plus
remote_transform_tabs_test: PASS, 11.672s, forward_plus
runtime_ui_priority_test: PASS, 6.39s, forward_plus
scene_data_test: PASS, 15.172s, forward_plus
scene_tree_shortcuts_test: PASS, 6.172s, forward_plus
shader_library_browser_test: PASS, 10.484s, forward_plus
shader_library_render_test: PASS, 9.969s, forward_plus
shader_library_ui_test: PASS, 9.219s, forward_plus
shader_material_test: PASS, 6.594s, forward_plus
shader_time_test: PASS, 4.5s, forward_plus
shader_uniform_groups_test: PASS, 5.984s, forward_plus
stroke_controls_test: PASS, 5.312s, forward_plus
stroke_correct_paint_test: PASS, 7.266s, forward_plus
stroke_corrector_test: PASS, 14.328s, forward_plus
stroke_high_scale_test: PASS, 11.141s, forward_plus
templates_noise_split_test: PASS, 6.515s, forward_plus
timeline_edit_test: PASS, 6.187s, forward_plus
timeline_focus_test: PASS, 5.938s, forward_plus
timeline_layers_test: PASS, 6.266s, forward_plus
timeline_media_tools_test: PASS, 6.187s, forward_plus
timeline_multi_edit_playback_snap_test: PASS, 7.032s, forward_plus
timeline_obstruction_visibility_test: PASS, 3.875s, forward_plus
timeline_parenting_test: PASS, 6.922s, forward_plus
timeline_reveal_overlap_test: PASS, 3.796s, forward_plus
timeline_sections_test: PASS, 6.422s, forward_plus
timeline_sibling_collision_test: PASS, 3.938s, forward_plus
timeline_test: PASS, 7.031s, forward_plus
ui_actor_test: PASS, 6.75s, forward_plus
ui_interaction_text_test: PASS, 6.453s, forward_plus
video_link_test: PASS, 6.985s, forward_plus
viewport_and_scroll_test: PASS, 7.797s, forward_plus

SOURCE BASELINE
Hi62384/kiwi-studios-2 @ f3175ed445809a0d3e427ba7d5aba5fb661e16cb

CHANGED FILES
Workspaces/ImageWorkspace/image_canvas.gd
Workspaces/ImageWorkspace/image_document.gd
Workspaces/ImageWorkspace/image_layer.gd
Workspaces/ImageWorkspace/image_live_eraser.gd
Workspaces/ImageWorkspace/image_live_eraser.gd.uid
Workspaces/ImageWorkspace/image_material_stamps.gd
Workspaces/ImageWorkspace/image_material_stamps.gd.uid
Workspaces/ImageWorkspace/image_renderer.gd
Workspaces/ImageWorkspace/image_selection_fill.gd
Workspaces/ImageWorkspace/image_warp_toolbar.gd
Workspaces/ImageWorkspace/image_workspace.gd
Workspaces/ImageWorkspace/live_material_template.gd
Workspaces/ImageWorkspace/live_material_template.gd.uid
Workspaces/ImageWorkspace/live_paint_region.gd
Workspaces/ImageWorkspace/live_paint_region.gd.uid
Workspaces/ImageWorkspace/texture_material.gd
Workspaces/ImageWorkspace/texture_material_browser.gd
Workspaces/ImageWorkspace/texture_material_library.gd
Workspaces/ImageWorkspace/texture_material_renderer.gd
Workspaces/ImageWorkspace/texture_repair_ui.gd
Workspaces/SceneWorkspace/scripts/ShaderEditor/shader_code_editor.gd
Workspaces/SceneWorkspace/scripts/ShaderEditor/shader_documentation_popup.gd
Workspaces/SceneWorkspace/scripts/Timeline/actor_inspector.gd
Workspaces/SceneWorkspace/scripts/Timeline/actor_natural_material_editor.gd
Workspaces/SceneWorkspace/scripts/Timeline/actor_natural_material_editor.gd.uid
Workspaces/ShaderWorkspace/library/catalog.json
Workspaces/ShaderWorkspace/library/samples/canvas_item_alpha_mask.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_alpha_mask.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_animated_glow.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_animated_glow.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_animated_light_sweep.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_animated_light_sweep.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_animated_noise.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_animated_noise.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_blur.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_blur.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_brightness_contrast.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_brightness_contrast.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_chromatic_aberration.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_chromatic_aberration.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_color_palette_swap.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_color_palette_swap.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_color_replacement.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_color_replacement.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_comic_halftone.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_comic_halftone.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_crosshatching.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_crosshatching.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_crt_display.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_crt_display.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_dissolve.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_dissolve.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_dissolve_with_glowing_edges.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_dissolve_with_glowing_edges.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_drop_shadow.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_drop_shadow.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_energy_effect.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_energy_effect.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_film_grain.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_film_grain.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_fire_effect.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_fire_effect.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_flowing_water.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_flowing_water.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_glitch.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_glitch.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_glow.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_glow.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_gradient_fill.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_gradient_fill.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_gradient_mask.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_gradient_mask.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_heat_distortion.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_heat_distortion.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_hologram.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_hologram.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_hue_shift.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_hue_shift.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_inner_outline.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_inner_outline.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_inner_shadow.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_inner_shadow.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_moving_clouds.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_moving_clouds.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_moving_gradient.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_moving_gradient.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_multicolor_gradient.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_multicolor_gradient.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_outline.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_outline.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_pencil_shading.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_pencil_shading.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_pixel_art_shading.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_pixel_art_shading.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_pixelation.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_pixelation.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_portal_effect.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_portal_effect.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_posterization.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_posterization.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_retro_display.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_retro_display.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_ripple.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_ripple.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_rounded_corners.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_rounded_corners.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_saturation.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_saturation.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_scanlines.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_scanlines.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_scrolling_texture.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_scrolling_texture.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_shake.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_shake.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_sharpen.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_sharpen.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_soft_glow.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_soft_glow.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_solid_color.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_solid_color.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_texture_tint.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_texture_tint.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_transparency_fade.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_transparency_fade.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_vhs_effect.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_vhs_effect.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_vignette.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_vignette.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_water_surface.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_water_surface.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_wave_distortion.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_wave_distortion.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_wind_movement.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_wind_movement.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/canvas_item_wobble.gdshader
Workspaces/ShaderWorkspace/library/samples/canvas_item_wobble.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/fog_animated_fog.gdshader
Workspaces/ShaderWorkspace/library/samples/fog_animated_fog.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/fog_basic_fog.gdshader
Workspaces/ShaderWorkspace/library/samples/fog_basic_fog.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/fog_colored_fog.gdshader
Workspaces/ShaderWorkspace/library/samples/fog_colored_fog.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/fog_height_based_fog.gdshader
Workspaces/ShaderWorkspace/library/samples/fog_height_based_fog.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/fog_layered_fog.gdshader
Workspaces/ShaderWorkspace/library/samples/fog_layered_fog.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/fog_localized_fog.gdshader
Workspaces/ShaderWorkspace/library/samples/fog_localized_fog.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/fog_procedural_noise_fog.gdshader
Workspaces/ShaderWorkspace/library/samples/fog_procedural_noise_fog.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/fog_swirling_fog.gdshader
Workspaces/ShaderWorkspace/library/samples/fog_swirling_fog.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/particles_dust.gdshader
Workspaces/ShaderWorkspace/library/samples/particles_dust.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/particles_embers.gdshader
Workspaces/ShaderWorkspace/library/samples/particles_embers.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/particles_energy_particles.gdshader
Workspaces/ShaderWorkspace/library/samples/particles_energy_particles.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/particles_falling_leaves.gdshader
Workspaces/ShaderWorkspace/library/samples/particles_falling_leaves.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/particles_fire.gdshader
Workspaces/ShaderWorkspace/library/samples/particles_fire.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/particles_fireflies.gdshader
Workspaces/ShaderWorkspace/library/samples/particles_fireflies.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/particles_floating_particles.gdshader
Workspaces/ShaderWorkspace/library/samples/particles_floating_particles.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/particles_magical_particles.gdshader
Workspaces/ShaderWorkspace/library/samples/particles_magical_particles.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/particles_rain.gdshader
Workspaces/ShaderWorkspace/library/samples/particles_rain.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/particles_smoke.gdshader
Workspaces/ShaderWorkspace/library/samples/particles_smoke.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/particles_snow.gdshader
Workspaces/ShaderWorkspace/library/samples/particles_snow.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/particles_sparks.gdshader
Workspaces/ShaderWorkspace/library/samples/particles_sparks.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/sky_animated_stars.gdshader
Workspaces/ShaderWorkspace/library/samples/sky_animated_stars.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/sky_atmospheric_horizon.gdshader
Workspaces/ShaderWorkspace/library/samples/sky_atmospheric_horizon.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/sky_basic_sky_gradient.gdshader
Workspaces/ShaderWorkspace/library/samples/sky_basic_sky_gradient.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/sky_daytime_sky.gdshader
Workspaces/ShaderWorkspace/library/samples/sky_daytime_sky.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/sky_moving_clouds.gdshader
Workspaces/ShaderWorkspace/library/samples/sky_moving_clouds.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/sky_night_sky.gdshader
Workspaces/ShaderWorkspace/library/samples/sky_night_sky.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/sky_procedural_clouds.gdshader
Workspaces/ShaderWorkspace/library/samples/sky_procedural_clouds.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/sky_procedural_stars.gdshader
Workspaces/ShaderWorkspace/library/samples/sky_procedural_stars.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/sky_simple_cloud_layer.gdshader
Workspaces/ShaderWorkspace/library/samples/sky_simple_cloud_layer.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/sky_space_background.gdshader
Workspaces/ShaderWorkspace/library/samples/sky_space_background.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/sky_stylized_sky.gdshader
Workspaces/ShaderWorkspace/library/samples/sky_stylized_sky.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/sky_sunset_sky.gdshader
Workspaces/ShaderWorkspace/library/samples/sky_sunset_sky.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_animated_surface_noise.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_animated_surface_noise.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_animated_texture_coordinates.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_animated_texture_coordinates.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_basic_pbr_material.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_basic_pbr_material.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_bending_vegetation.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_bending_vegetation.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_cartoon_lighting.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_cartoon_lighting.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_cel_shading.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_cel_shading.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_crystal.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_crystal.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_dissolve.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_dissolve.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_dissolving_mesh.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_dissolving_mesh.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_dithered_transparency.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_dithered_transparency.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_emission.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_emission.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_energy_barrier.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_energy_barrier.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_flowing_lava.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_flowing_lava.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_force_field.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_force_field.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_fresnel.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_fresnel.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_glass.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_glass.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_grass_surface.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_grass_surface.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_growth_animation.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_growth_animation.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_height_based_texture_blending.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_height_based_texture_blending.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_holographic_surface.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_holographic_surface.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_ice.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_ice.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_metallic_surface.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_metallic_surface.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_moss_coverage.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_moss_coverage.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_moving_water.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_moving_water.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_mud.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_mud.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_normal_mapping.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_normal_mapping.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_object_interaction_ripples.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_object_interaction_ripples.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_outline_highlight.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_outline_highlight.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_procedural_metal.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_procedural_metal.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_procedural_rock.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_procedural_rock.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_procedural_terrain.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_procedural_terrain.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_procedural_wood.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_procedural_wood.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_pulsating_surface.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_pulsating_surface.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_rim_lighting.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_rim_lighting.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_rough_surface.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_rough_surface.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_sand.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_sand.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_selection_highlight.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_selection_highlight.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_shield_effect.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_shield_effect.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_slope_based_texture_blending.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_slope_based_texture_blending.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_snow_accumulation.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_snow_accumulation.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_stylized_water.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_stylized_water.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_texture_blending.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_texture_blending.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_toon_shading.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_toon_shading.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_transparent_surface.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_transparent_surface.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_triplanar_texturing.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_triplanar_texturing.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_unshaded_material.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_unshaded_material.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_vertex_color_material.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_vertex_color_material.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_vertex_displacement.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_vertex_displacement.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_vertex_waves.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_vertex_waves.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_wet_surface.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_wet_surface.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_wind_deformed_grass.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_wind_deformed_grass.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_wind_deformed_leaves.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_wind_deformed_leaves.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_wobbling_mesh.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_wobbling_mesh.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_world_aligned_texturing.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_world_aligned_texturing.gdshader.uid
Workspaces/ShaderWorkspace/library/samples/spatial_x_ray_effect.gdshader
Workspaces/ShaderWorkspace/library/samples/spatial_x_ray_effect.gdshader.uid
Workspaces/ShaderWorkspace/library/shader_library_data.gd
Workspaces/ShaderWorkspace/library/shader_library_data.gd.uid
Workspaces/ShaderWorkspace/library/shader_sample_catalog.gd
Workspaces/ShaderWorkspace/library/shader_sample_catalog.gd.uid
Workspaces/ShaderWorkspace/library/templates/template_basic_pbr_shader.gdshader
Workspaces/ShaderWorkspace/library/templates/template_basic_pbr_shader.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_canvas_item_shader.gdshader
Workspaces/ShaderWorkspace/library/templates/template_canvas_item_shader.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_canvas_post_processing_template.gdshader
Workspaces/ShaderWorkspace/library/templates/template_canvas_post_processing_template.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_empty_spatial_shader.gdshader
Workspaces/ShaderWorkspace/library/templates/template_empty_spatial_shader.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_fog_shader_template.gdshader
Workspaces/ShaderWorkspace/library/templates/template_fog_shader_template.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_multi_texture_blending_template.gdshader
Workspaces/ShaderWorkspace/library/templates/template_multi_texture_blending_template.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_particle_shader_template.gdshader
Workspaces/ShaderWorkspace/library/templates/template_particle_shader_template.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_procedural_noise_shader_template.gdshader
Workspaces/ShaderWorkspace/library/templates/template_procedural_noise_shader_template.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_screen_distortion_template.gdshader
Workspaces/ShaderWorkspace/library/templates/template_screen_distortion_template.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_shader_with_organized_uniform_groups.gdshader
Workspaces/ShaderWorkspace/library/templates/template_shader_with_organized_uniform_groups.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_sky_shader_template.gdshader
Workspaces/ShaderWorkspace/library/templates/template_sky_shader_template.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_terrain_shader_template.gdshader
Workspaces/ShaderWorkspace/library/templates/template_terrain_shader_template.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_textured_canvas_shader.gdshader
Workspaces/ShaderWorkspace/library/templates/template_textured_canvas_shader.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_textured_pbr_shader.gdshader
Workspaces/ShaderWorkspace/library/templates/template_textured_pbr_shader.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_toon_shader_template.gdshader
Workspaces/ShaderWorkspace/library/templates/template_toon_shader_template.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_transparent_material_template.gdshader
Workspaces/ShaderWorkspace/library/templates/template_transparent_material_template.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_triplanar_shader_template.gdshader
Workspaces/ShaderWorkspace/library/templates/template_triplanar_shader_template.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_vegetation_shader_template.gdshader
Workspaces/ShaderWorkspace/library/templates/template_vegetation_shader_template.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_vertex_animation_template.gdshader
Workspaces/ShaderWorkspace/library/templates/template_vertex_animation_template.gdshader.uid
Workspaces/ShaderWorkspace/library/templates/template_water_shader_template.gdshader
Workspaces/ShaderWorkspace/library/templates/template_water_shader_template.gdshader.uid
Workspaces/ShaderWorkspace/shader_preview_logger.gd
Workspaces/ShaderWorkspace/shader_preview_logger.gd.uid
Workspaces/ShaderWorkspace/shader_sample_application.gd
Workspaces/ShaderWorkspace/shader_sample_application.gd.uid
Workspaces/ShaderWorkspace/shader_sample_browser.gd
Workspaces/ShaderWorkspace/shader_sample_browser.gd.uid
Workspaces/ShaderWorkspace/shader_sample_preview.gd
Workspaces/ShaderWorkspace/shader_sample_preview.gd.uid
Workspaces/ShaderWorkspace/shader_workspace.gd
docs/natural_materials_and_shader_library.md
scripts/actors/examples/basic_actor.gd
scripts/actors/examples/basic_actor_catalog.tres
scripts/actors/examples/natural_material.tres
scripts/actors/tests/actor_picker_test.gd
scripts/actors/tests/image_material_painting_test.gd
scripts/actors/tests/image_material_painting_test.gd.uid
scripts/actors/tests/image_material_stamps_test.gd
scripts/actors/tests/image_material_stamps_test.gd.uid
scripts/actors/tests/image_repair_test.gd
scripts/actors/tests/image_selection_fill_test.gd
scripts/actors/tests/image_texture_material_test.gd
scripts/actors/tests/live_material_benchmark.gd
scripts/actors/tests/live_material_benchmark.gd.uid
scripts/actors/tests/live_material_cache_test.gd
scripts/actors/tests/live_material_cache_test.gd.uid
scripts/actors/tests/live_material_preview_test.gd
scripts/actors/tests/live_material_preview_test.gd.uid
scripts/actors/tests/live_material_templates_test.gd
scripts/actors/tests/live_material_templates_test.gd.uid
scripts/actors/tests/live_recording_placement_test.gd
scripts/actors/tests/media_preview_recording_test.gd
scripts/actors/tests/natural_material_browser_test.gd
scripts/actors/tests/natural_material_browser_test.gd.uid
scripts/actors/tests/natural_material_scene_render_test.gd
scripts/actors/tests/natural_material_scene_render_test.gd.uid
scripts/actors/tests/natural_material_test.gd
scripts/actors/tests/natural_material_test.gd.uid
scripts/actors/tests/run_regressions.py
scripts/actors/tests/scene_data_test.gd
scripts/actors/tests/shader_library_browser_test.gd
scripts/actors/tests/shader_library_browser_test.gd.uid
scripts/actors/tests/shader_library_render_test.gd
scripts/actors/tests/shader_library_render_test.gd.uid
scripts/actors/tests/shader_library_ui_test.gd
scripts/actors/tests/shader_library_ui_test.gd.uid
scripts/actors/tests/shader_material_test.gd
scripts/actors/tests/stroke_controls_test.gd
scripts/actors/tests/timeline_media_tools_test.gd
scripts/actors/tests/ui_interaction_text_test.gd
scripts/materials/natural_material_definitions.gd
scripts/materials/natural_material_definitions.gd.uid
scripts/materials/natural_material_engine.gd
scripts/materials/natural_material_engine.gd.uid
scripts/materials/natural_material_engine_test.gd
scripts/materials/natural_material_engine_test.gd.uid
scripts/materials/natural_material_pattern.gdshaderinc
scripts/materials/natural_material_pattern.gdshaderinc.uid
scripts/materials/natural_material_presets.gd
scripts/materials/natural_material_presets.gd.uid
scripts/materials/natural_material_shader_source.gd
scripts/materials/natural_material_shader_source.gd.uid
scripts/tests/rebuild_shader_library_index.py
scripts/tests/shader_library_validation.gd
scripts/tests/shader_library_validation.gd.uid

REPRODUCTION
See docs/natural_materials_and_shader_library.md. Evidence and logs are generated under .godot/verification and are present in the local working tree but intentionally excluded from the source patch.
